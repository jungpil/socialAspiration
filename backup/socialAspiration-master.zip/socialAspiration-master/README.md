# socialAspiration
Extension of Greve (OrgSci 2002) to study social aspiration

## Usage
- Download / clone repository
- create folder "out" for output files
- run "java app.Simulation [config file]"

## ToDo Items
